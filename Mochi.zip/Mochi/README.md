# Mochi - floating chibi AI companion for Android

A small animated chibi girl floats over all your apps, wanders around, and talks to you (text or voice) through **any AI APIs you plug in**, with an advanced routing hub.

## Features
- Floating chibi (drawn in code, moods: happy / shy / sad / angry / sleepy / smug / excited), walks, sits, sleeps, waves
- Drag her anywhere, tap to chat, long-press to pat her
- Call her out: notification button, Quick Settings tile, home-screen icon "Call Mochi"
- Voice input (speech recognizer) and spoken replies (cute high-pitch TTS)
- **API hub**: OpenAI-compatible (OpenAI, Groq, OpenRouter, DeepSeek, Together, Mistral, Cerebras, Ollama/local, your own wrappers), Anthropic, Gemini
- **Routing**: priority+failover, round-robin, random, weighted, fastest (learns latency); rules by regex / length / voice -> prefer a tag or provider; retries; circuit breaker with cooldown; route tester; per-provider stats
- Personality prompt, name, size, voice all editable

## Build the APK (no PC)
1. Create an empty GitHub repo (e.g. `mochi`).
2. Push this folder to it (from Termux):
   ```
   pkg install git unzip
   unzip Mochi.zip && cd Mochi
   git init && git add . && git commit -m "mochi"
   git branch -M main
   git remote add origin https://github.com/YOUR_USER/mochi.git
   git push -u origin main
   ```
   (use a GitHub personal access token as the password)
3. GitHub Actions builds automatically (Actions tab, ~4-6 min).
4. Open `https://github.com/YOUR_USER/mochi/releases/tag/latest-build` on your phone, download `mochi.apk`, install it (allow "install unknown apps").
5. Open Mochi: tap *Allow overlay*, *Mic + notifications*, add a provider in the **APIs** tab, then *Start Mochi*.

Every push rebuilds the APK, and it installs as an update (fixed signing key), so your settings stay.
